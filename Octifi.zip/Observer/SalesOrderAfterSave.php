<?php

namespace Octifi\Octifi\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class SalesOrderAfterSave implements ObserverInterface
{

    /**
     * Main function
     *
     * @param Observer $observer
     * @return mixed
     */
    public function execute(Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
        if ($order instanceof \Magento\Framework\Model\AbstractModel) {
            if ($order->getState() == 'complete') {
                $payment = $order->getPayment();
                $method = $payment->getMethodInstance()->getCode();
                if ($method == 'octifi') {
                    $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                    $configHelper = $objectManager->create(\Octifi\Octifi\Helper\Config::class);
                    $_OCTIFI_ENV = $configHelper->getEnvConfig();

                    $model = $objectManager->get(Octifi\Octifi\Model\Pay::class);
                    $helper = $objectManager->get(Octifi\Octifi\Helper\Data::class);
                    $messageManager = $objectManager->get(\Magento\Framework\Message\ManagerInterface::class);
                    
                    $order_response = $helper->getTransaction($order->getId());
                    if (!$order_response) {
                        $message = 'LatitudePay Capture attempted failed. ';
                        $message .= 'Since LatitudePay Charge ID not available for this order';
                        $messageManager->addError($message);
                        return $this;
                    }

                    $gatewayResponse = json_decode($order_response, true);
                    
                    if (!isset($gatewayResponse['OctiFi_Charge_Id'])) {
                        $message = 'LatitudePay Capture attempted failed. ';
                        $message .= 'Since LatitudePay Charge ID not available for this order';
                        $messageManager->addError($message);
                        return $this;
                    }
                    
                    $OctiFi_Charge_Id = $gatewayResponse['OctiFi_Charge_Id'];
                    $OctiFi_Payment_Action = '';
                    if (isset($gatewayResponse['OctiFi_Payment_Action'])) {
                        $OctiFi_Payment_Action = $gatewayResponse['OctiFi_Payment_Action'];
                    }
                    
                    $OctiFi_Captured = 0;
                    if (isset($gatewayResponse['OctiFi_Captured'])) {
                        $OctiFi_Captured = $gatewayResponse['OctiFi_Captured'];
                    }

                    if ($OctiFi_Payment_Action == 'capture') {
                        return $this;
                    }
                    
                    if ($OctiFi_Captured == 1) {
                        return $this;
                    }
                    
                    $header = [
                        "accept: application/json",
                        "Content-Type: application/json",
                        "Authorization: Api-Key ".$model->getConfigValue('private_api_key')
                    ];
                    
                    $params = [
                        "charge_id" => $OctiFi_Charge_Id
                    ];
                    
                    $environment = $model->getConfigValue('testmode');
                    $selected_country = $model->getConfigValue('new_payment_country');
                    
                    if ($environment) {
                        $options2 = [
                            CURLOPT_URL => $_OCTIFI_ENV['OCTIFI_CHARGE_URL'],
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_HEADER => false,
                            CURLOPT_SSL_VERIFYPEER => false,
                            CURLOPT_POST => true,
                            CURLOPT_POSTFIELDS => json_encode($params),
                            CURLOPT_HTTPHEADER => $header
                        ];
                    } else {
                        if ($selected_country == "SG") {
                            $options2 = [
                                CURLOPT_URL => $_OCTIFI_ENV['OCTIFI_CHARGE_URL_SG'],
                                CURLOPT_RETURNTRANSFER => true,
                                CURLOPT_HEADER => false,
                                CURLOPT_SSL_VERIFYPEER => false,
                                CURLOPT_POST => true,
                                CURLOPT_POSTFIELDS => json_encode($params),
                                CURLOPT_HTTPHEADER => $header
                            ];
                        } elseif ($selected_country == "MY") {
                            $options2 = [
                                CURLOPT_URL => $_OCTIFI_ENV['OCTIFI_CHARGE_URL_MY'],
                                CURLOPT_RETURNTRANSFER => true,
                                CURLOPT_HEADER => false,
                                CURLOPT_SSL_VERIFYPEER => false,
                                CURLOPT_POST => true,
                                CURLOPT_POSTFIELDS => json_encode($params),
                                CURLOPT_HTTPHEADER => $header
                            ];
                        }
                    }
                    $ch2 = curl_init();
                    curl_setopt_array($ch2, $options2);
                    $response3 = curl_exec($ch2);

                    if (!$response3) {
                        $error_message = curl_error($ch2);
                        $message = 'LatitudePay Capture attempted failed. Error from gateway:'.$error_message;
                        $messageManager->addError($message);
                        curl_close($ch2);
                    } else {
                        curl_close($ch2);
                        $result2 = json_decode($response3, true);
                        $model->log($options2);
                        $model->log($result2);
                        if ($result2['status_code'] == 200) {
                            $charge_status = $result2['data']['ChargeStatus'];
                            $captureStatus = 'Payment successful with LatitudePay(Captured). Charge Status: ';
                            $comment = __($captureStatus . $charge_status);
                            $capture_status = 1;
                            $gatewayResponse['OctiFi_Captured'] = $capture_status;
                            $gatewayResponseJson = json_encode($gatewayResponse);
                            $helper->updateTransaction($order->getId(), $gatewayResponseJson);

                            $order->addStatusHistoryComment($comment);
                            $messageManager->addSuccess($comment);
                        } else {
                            $error_message = $result2['message'].'. '.$result2['errors']['non_field_errors'][0];
                            $message = 'LatitudePay Capture attempted failed. Error from gateway:'.$error_message;
                            $messageManager->addError($message);
                        }
                    }
                }
            }
        }
        return $this;
    }
}
