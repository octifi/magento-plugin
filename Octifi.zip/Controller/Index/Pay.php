<?php
namespace Octifi\Octifi\Controller\Index;

class Pay extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Octifi\Octifi\Helper\Data
     */
    protected $helper;
    /**
     * @var \Octifi\Octifi\Model\Pay
     */
    protected $payment;
    /**
     * @var \Magento\Sales\Model\OrderFactory
     */
    protected $orderFactory;

    /**
     * Constructor
     *
     * @param \Octifi\Octifi\Helper\Data $helper
     * @param \Octifi\Octifi\Model\Pay $payment
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param \Magento\Framework\App\Action\Context $context
     */
    public function __construct(
        \Octifi\Octifi\Helper\Data $helper,
        \Octifi\Octifi\Model\Pay $payment,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Framework\App\Action\Context $context
    ) {
        $this->helper = $helper;
        $this->payment = $payment;
        $this->orderFactory = $orderFactory;
        parent::__construct($context);
    }

    /**
     * Main function
     */
    public function execute()
    {
        $this->_view->loadLayout();
        $this->_view->getLayout()->initMessages();
        $this->_view->renderLayout();
    }
}
