<?php
namespace Octifi\Octifi\Controller\Index;

use Magento\Framework\Controller\ResultFactory;

class Callback extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Octifi\Octifi\Helper\Data
     */
    protected $helper;
    /**
     * @var \Octifi\Octifi\Model\Pay
     */
    protected $payment;
    /**
     * @var \Magento\Sales\Model\OrderFactory
     */
    protected $orderFactory;
    /**
     * @var \Magento\Framework\Controller\ResultFactory
     */
    protected $resultFactory;

    /**
     * Constructor
     *
     * @param \Octifi\Octifi\Helper\Data $helper
     * @param \Octifi\Octifi\Model\Pay $payment
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param \Magento\Framework\App\Action\Context $context
     */
    public function __construct(
        \Octifi\Octifi\Helper\Data $helper,
        \Octifi\Octifi\Model\Pay $payment,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Framework\App\Action\Context $context
    ) {
        $this->helper = $helper;
        $this->payment = $payment;
        $this->orderFactory = $orderFactory;
        parent::__construct($context);
    }

    /**
     * Main function
     *
     * @return mixed
     */
    public function execute()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $configHelper = $objectManager->create(\Octifi\Octifi\Helper\Config::class);
        $_OCTIFI_ENV = $configHelper->getEnvConfig();

        $params = $this->getRequest()->getParams();
        if (isset($params['data'])) {
            $data = $params['data'];
            $jsonData =  base64_decode($data);
            $response = json_decode($jsonData, true);
        } else {
            $response = $params;
        }

        $order_id = $response['merchant_order_id'];
        $order = $this->getOrder($order_id);
        $model = $this->_objectManager->get(\Octifi\Octifi\Model\Pay::class);
        $session = $this->_objectManager->get(\Magento\Checkout\Model\Session::class);
        $environment = $model->getConfigValue('testmode');
        $selected_country = $model->getConfigValue('new_payment_country');
        
        $error_message = '';
        $additional_comment = '';

        /** @var \Magento\Framework\Controller\Result\Raw $returnObject */
        $returnObject = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_RAW);
        
        if ($response['statuscode'] == 200) {
            $checkout_token = $response['checkout_token'];
            $header = [
                "accept: application/json",
                "Content-Type: application/json",
                "Authorization: Api-Key ".$model->getConfigValue('private_api_key')
            ];

            $is_capture = false;
            if ($model->getConfigValue('new_payment_action') == 'capture') {
                $is_capture = true;
            }

            $params = [
                "bill_total_amount" => $this->getFormattedAmount($order->getGrandTotal()),
                "bill_currency" => $order->getOrderCurrencyCode(),
                "bill_tax_amount" => $this->getFormattedAmount($order->getTaxAmount()),
                "is_capture" => $is_capture
            ];

            if ($environment) {
                $options = [
                    CURLOPT_URL => $_OCTIFI_ENV['OCTIFI_CREATE_URL'].$checkout_token."/",
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_HEADER => false,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_POST => true,
                    CURLOPT_POSTFIELDS => json_encode($params),
                    CURLOPT_HTTPHEADER => $header
                ];
            } else {
                if ($selected_country == "SG") {
                    $options = [
                    CURLOPT_URL => $_OCTIFI_ENV['OCTIFI_CREATE_URL_SG'].$checkout_token."/",
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_HEADER => false,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_POST => true,
                    CURLOPT_POSTFIELDS => json_encode($params),
                    CURLOPT_HTTPHEADER => $header
                    ];
                } elseif ($selected_country == "MY") {
                    $options = [
                        CURLOPT_URL => $_OCTIFI_ENV['OCTIFI_CREATE_URL_MY'].$checkout_token."/",
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_HEADER => false,
                        CURLOPT_SSL_VERIFYPEER => false,
                        CURLOPT_POST => true,
                        CURLOPT_POSTFIELDS => json_encode($params),
                        CURLOPT_HTTPHEADER => $header
                    ];
                }
            }
            $ch = curl_init();
            curl_setopt_array($ch, $options);
            $response2 = curl_exec($ch);

            if (!$response2) {
                $error_message = curl_error($ch);
                curl_close($ch);
            } else {
                curl_close($ch);
                $result = json_decode($response2, true);
                $model->log($options);
                $model->log($result);
                if ($result['status_code'] == 200) {
                   
                    $OctiFi_Charge_Id = $result['data']['charge_id'];
                    $OctiFi_Txn_Number = $result['data']['order_payment_details']['data']['txn_number'];
                    
                    $gatewayResponse['OctiFi_Charge_Id'] = $OctiFi_Charge_Id;
                    $gatewayResponse['OctiFi_Txn_Number'] = $OctiFi_Txn_Number;
                    $gatewayResponse['OctiFi_Payment_Action'] = $model->getConfigValue('new_payment_action');

                    $gatewayResponseJson = json_encode($gatewayResponse);
                    
                    $this->helper->updateTransaction($order->getId(), $gatewayResponseJson);
                    
                    if ($is_capture) {

                        $params = [
                            "charge_id" => $OctiFi_Charge_Id
                        ];

                        if ($environment) {
                             $options2 = [
                                CURLOPT_URL => $_OCTIFI_ENV['OCTIFI_CHARGE_DETAIL_URL'].$OctiFi_Charge_Id."/",
                                CURLOPT_RETURNTRANSFER => true,
                                CURLOPT_HEADER => false,
                                CURLOPT_SSL_VERIFYPEER => false,
                                CURLOPT_HTTPHEADER => $header
                             ];
                        } else {
                            if ($selected_country == "SG") {
                                $options2 = [
                                CURLOPT_URL => $_OCTIFI_ENV['OCTIFI_CHARGE_DETAIL_URL_SG'].$OctiFi_Charge_Id."/",
                                CURLOPT_RETURNTRANSFER => true,
                                CURLOPT_HEADER => false,
                                CURLOPT_SSL_VERIFYPEER => false,
                                CURLOPT_HTTPHEADER => $header
                                ];
                            } elseif ($selected_country == "MY") {
                                $options2 = [
                                    CURLOPT_URL => $_OCTIFI_ENV['OCTIFI_CHARGE_DETAIL_URL_MY'].$OctiFi_Charge_Id."/",
                                    CURLOPT_RETURNTRANSFER => true,
                                    CURLOPT_HEADER => false,
                                    CURLOPT_SSL_VERIFYPEER => false,
                                    CURLOPT_HTTPHEADER => $header
                                ];
                            }
                        }

                        $ch2 = curl_init();
                        curl_setopt_array($ch2, $options2);
                        $response3 = curl_exec($ch2);

                        if (!$response3) {
                            $error_message = curl_error($ch2);
                            curl_close($ch2);
                        } else {
                            curl_close($ch2);
                            $result2 = json_decode($response3, true);
                            $model->log($options2);
                            $model->log($result2);
                            if ($result2['status_code'] == 200) {
                                $charge_status = $result2['data']['state'];
                                $comment = __('Payment successful with LatitudePay(Authorized and Captured). ');
                                $comment .= __('Checkout Token: '.$checkout_token.'. ');
                                $comment .= __('Charge ID: '.$OctiFi_Charge_Id.'. ');
                                $comment .= __('Charge Status: '.$charge_status.'. ');
                                $comment .= __('Transaction ID: '). $OctiFi_Txn_Number;
                                
                                if ($charge_status == 'ChargeState.CAPTURED') {
                                    $capture_status = 1;
                                }
                                $gatewayResponse['OctiFi_Captured'] = $capture_status;
                                $gatewayResponseJson = json_encode($gatewayResponse);
                                $this->helper->updateTransaction($order->getId(), $gatewayResponseJson);

                                $state = $model->getConfigValue('new_order_status');
                                if (empty($state)) {
                                    $state = \Magento\Sales\Model\Order::STATE_PROCESSING;
                                }
                                $status = $state;

                                $order->setState($state);
                                $order->setStatus($status);
                                $order->setTotalPaid($order->getGrandTotal());
                                $order->addStatusHistoryComment($comment, $status);
                                $order->save();
                                $successUrl = $model->getCheckoutSuccessUrl();

                                $returnObject->setContents('<script>window.top.location.href = "' . $successUrl . '";</script>');

                                return $returnObject;
                            } else {
                                $error_message = $result2['message'].'. '.$result2['errors']['non_field_errors'][0];

                                $additional_comment = __('Checkout Token: '.$checkout_token.'. ');
                                $additional_comment .= __('Charge ID: '.$OctiFi_Charge_Id.'. ');
                                $additional_comment .= __('Transaction ID: '). $OctiFi_Txn_Number;
                            }
                        }
                    } else {
                        $charge_status = $result['data']['order_detail']['status'];
                        
                        $OctiFi_Charge_Id = 'Not created';
                        $OctiFi_Txn_Number = '';
                        
                        if (isset($result['data']['charge_id'])) {
                            $OctiFi_Charge_Id = $result['data']['charge_id'];
                            $gatewayResponse['OctiFi_Charge_Id'] = $OctiFi_Charge_Id;
                        }
                        
                        if (isset($result['data']['order_payment_details']['data']['txn_number'])) {
                            $OctiFi_Txn_Number = $result['data']['order_payment_details']['data']['txn_number'];
                            $gatewayResponse['OctiFi_Txn_Number'] = $OctiFi_Txn_Number;
                        }
                        $gatewayResponseJson = json_encode($gatewayResponse);

                        $this->helper->updateTransaction($order->getId(), $gatewayResponseJson);
                        
                        $additional_comment = __('Checkout Token: '.$checkout_token.'. ');
                        $additional_comment .= __('Charge ID: '.$OctiFi_Charge_Id.'. ');
                        $additional_comment .= __('Transaction ID: '). $OctiFi_Txn_Number;
                        $authorizedStatus = 'Payment successful with OctiFi(Authorized). Charge Status: ';
                        $comment = __($authorizedStatus . $charge_status.'. ');
                        $comment .= $additional_comment;

                        $state = $model->getConfigValue('new_order_status');
                        if (empty($state)) {
                            $state = \Magento\Sales\Model\Order::STATE_PROCESSING;
                        }
                        $status = $state;

                        $order->setState($state);
                        $order->setStatus($status);
                        $order->setTotalPaid($order->getGrandTotal());
                        $order->addStatusHistoryComment($comment, $status);
                        $order->save();

                        $returnObject->setContents('<script>window.top.location.href = "' . $model->getCheckoutSuccessUrl().'";</script>');

                        return $returnObject;
                    }
                    
                } else {
                    $error_message = $result['message'].'. '.$result['errors']['non_field_errors'][0];
                    $additional_comment = __('Checkout Token: '.$checkout_token.'. ');
                    $OctiFi_Charge_Id = __('Not created');
                    if (isset($result['data']['charge_id'])) {
                        $OctiFi_Charge_Id = $result['data']['charge_id'];
                        $additional_comment .= __('Charge ID: '.$OctiFi_Charge_Id.'. ');
                    }
                }
            }
        } else {
            $error_message =  __('No Checkout Token from OctiFi');
        }

        if ($error_message) {
            $order->cancel();
            $message = __('Payment Failed with LatitudePay. Reason: '.$error_message);
            $_STATE_CANCELED = \Magento\Sales\Model\Order::STATE_CANCELED;
            $order->addStatusHistoryComment($message.' '.$additional_comment, $_STATE_CANCELED);
            $order->save();
            $session->restoreQuote();
            $this->messageManager->addError($message);

            $returnObject->setContents('<script>window.top.location.href = "'.$model->getCheckoutCartUrl().'";</script>');

            return $returnObject;
        }
    }
    
    /**
     * Gets order
     *
     * @param string $Id
     * @return mixed
     */
    public function getOrder($Id)
    {
        $orderFactory = $this->orderFactory->create();
        return $orderFactory->loadByIncrementId($Id);
    }
    
    /**
     * Gets formatted amount
     *
     * @param float $amount
     * @return float
     */
    public function getFormattedAmount($amount)
    {
        return round($amount, 2);
    }
}
