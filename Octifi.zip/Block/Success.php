<?php

namespace Octifi\Octifi\Block;

class Success extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Octifi\Octifi\Helper\Data $helper helper
     */
    protected $helper;
    /**
     * @var \Octifi\Octifi\Model\Pay $payment payment
     */
    protected $payment;

    /**
     * Constructor
     * @param \Octifi\Octifi\Helper\Data $helper
     * @param \Octifi\Octifi\Model\Pay $payment
     * @param \Magento\Catalog\Block\Product\Context $context
     * @param array $data
     */
    public function __construct(
        \Octifi\Octifi\Helper\Data $helper,
        \Octifi\Octifi\Model\Pay $payment,
        \Magento\Catalog\Block\Product\Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->helper = $helper;
        $this->payment = $payment;
    }
    
    /**
     * Gets status content
     */
    public function getStatusContent()
    {
        $order = $this->payment->getOrder();
        $payment = $order->getPayment();
        $method = $payment->getMethodInstance();
        if ($method && $payment->getMethod() == 'octifi') {
            $status_content = '';

            if ($order->getState() == \Magento\Sales\Model\Order::STATE_NEW) {
                $pendingMessage = 'Your payment status is pending, ';
                $pendingMessage .= 'we will update the status as soon as we receive notification ';
                $pendingMessage .= 'from LatitudePay System.';
                $status_content = __($pendingMessage);
            } elseif ($order->getState() == \Magento\Sales\Model\Order::STATE_PROCESSING) {
                $status_content = __('Your payment is successful with LatitudePay System.');
            } elseif ($order->getState() == \Magento\Sales\Model\Order::STATE_CANCELED) {
                $status_content = __('Your payment is failed with LatitudePay System.');
            }

            return $status_content;
        }
    }
}
