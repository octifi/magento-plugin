<?php
namespace Octifi\Octifi\Block\Adminhtml\Sales\Order;

class View extends \Magento\Backend\Block\Template
{
    /**
     * @var \Octifi\Octifi\Helper\Data $helper helper
     */
    protected $helper;
    /**
     * @var \Magento\Framework\App\RequestInterface $request request interface
     */
    protected $request;
    /**
     * @var \Magento\Sales\Model\OrderFactory $orderFactory order factory
     */
    protected $orderFactory;
    
    /**
     * Constructor
     *
     * @param \Octifi\Octifi\Helper\Data $helper
     * @param \Magento\Framework\App\RequestInterface $request
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param \Magento\Backend\Block\Template\Context $context
     * @param array $data
     */
    public function __construct(
        \Octifi\Octifi\Helper\Data $helper,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Backend\Block\Template\Context $context,
        array $data = []
    ) {
        $this->helper = $helper;
        $this->request = $request;
        $this->orderFactory = $orderFactory;
        parent::__construct($context, $data);
    }

    /**
     * Gets response values
     */
    public function getResponseValues()
    {
        $order_id = (int)$this->request->getParam('order_id');
        $order = $this->orderFactory->create()->load($order_id);
        $payment = $order->getPayment();
        $method = $payment->getMethodInstance()->getCode();

        if ($method == 'octifi') {
            $metaData = $this->helper->getTransaction($order->getId());
            $response = json_decode($metaData, true);
            $response['order_id'] = $order_id;
            return $response;
        }

        return false;
    }
}
