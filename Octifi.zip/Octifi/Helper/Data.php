<?php
namespace Octifi\Octifi\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    public $resource = '';
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\App\ResourceConnection $resource
    ) {
        parent::__construct($context);
        $this->resource = $resource;
    }
    
    public function getTransaction($order_id)
    {
        $connection = $this->resource->getConnection();
        $tableName = $this->resource->getTableName('octifi_order');
        $query = "select response from {$tableName} where order_id=".(int)($order_id);
        return $connection->fetchOne($query);
    }
    
    public function updateTransaction($order_id, $response='')
    {
        $connection = $this->resource->getConnection();
        $tableName = $this->resource->getTableName('octifi_order');
        
        $transaction = $this->getTransaction($order_id);
        if ($transaction) {
            $connection->update(
                $tableName, 
                [ 'response' => $response],
                "order_id=".$order_id    
            );
        } else {
            $connection->insert(
                $tableName, 
                ['response' => $response, 'order_id' => $order_id]
            );
        }
    }
}
