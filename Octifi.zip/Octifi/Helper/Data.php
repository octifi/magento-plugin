<?php
namespace Octifi\Octifi\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    public $resource = '';
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\App\ResourceConnection $resource
    ) {
        parent::__construct($context);
        $this->resource = $resource;
    }

    public function getTransaction($order_id)
    {
        $connection = $this->resource->getConnection();
        $tableName = $this->resource->getTableName('octifi_order');
        $query = "select response from {$tableName} where order_id=".(int)($order_id);
        return $connection->fetchOne($query);
    }
    
    public function updateTransaction($order_id, $response='')
    {
        $connection = $this->resource->getConnection();
        $tableName = $this->resource->getTableName('octifi_order');
        
        $transaction = $this->getTransaction($order_id);
        if ($transaction) {
            $connection->update(
                $tableName, 
                [ 'response' => $response],
                "order_id=".$order_id    
            );
        } else {
            $connection->insert(
                $tableName, 
                ['response' => $response, 'order_id' => $order_id]
            );
        }
    }

    public function showOctifiInstallmentText($price)
    {
        $showInstallment = 0;
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $scopeConfig = $objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface');
        $moduleEnable = $scopeConfig->getValue(
            'payment/octifi/active',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        $minimumSum = $scopeConfig->getValue(
            'payment/octifi/minimum_sum',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        $hideText = $scopeConfig->getValue(
            'payment/octifi/hide_text',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        if($moduleEnable == 1 && $hideText == 0){
            if($price > $minimumSum){
                $showInstallment = 1;
            }
        }

        return $showInstallment;
    }


    public function getProductPriceForOctifi($product)
    {
        $productPrice = 0;
        $regularPrice = 0;
        $specialPrice = 0;
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $_product = $objectManager->create('Magento\Catalog\Model\Product')->load($product->getId());
        if($_product->getTypeId() == 'simple'){
            $regularPrice = $_product->getPriceInfo()->getPrice('regular_price')->getValue();
            $specialPrice = $_product->getPriceInfo()->getPrice('special_price')->getValue();
        }

        if ($_product->getTypeId() == 'configurable') {
              $basePrice = $_product->getPriceInfo()->getPrice('regular_price');
              $regularPrice = $basePrice->getMinRegularAmount()->getValue();
              $specialPrice = $_product->getFinalPrice();
        }

        if ($_product->getTypeId() == 'bundle') {
              $regularPrice = $_product->getPriceInfo()->getPrice('regular_price')->getMinimalPrice()->getValue();
              $specialPrice = $_product->getPriceInfo()->getPrice('final_price')->getMinimalPrice()->getValue();            
        }

        if ($_product->getTypeId() == 'grouped') {
            $usedProds = $_product->getTypeInstance(true)->getAssociatedProducts($_product);            
            foreach ($usedProds as $child) {
                if ($child->getId() != $_product->getId()) {
                    if($regularPrice == 0){
                        $regularPrice = $child->getPrice();
                    }
                    if($regularPrice > $child->getPrice()){
                        $regularPrice = $child->getPrice();
                    }
                    if($specialPrice == 0){
                        $specialPrice = $child->getFinalPrice();
                    }
                    if($specialPrice > $child->getFinalPrice()){
                        $specialPrice = $child->getFinalPrice();
                    }
                }
            }
        }

        $productPrice = $regularPrice;
        if($specialPrice > 0){
            $productPrice = $specialPrice;
        }
        
        return $productPrice;
    }
}