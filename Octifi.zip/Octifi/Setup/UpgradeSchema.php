<?php
namespace Octifi\Octifi\Setup;

class UpgradeSchema implements \Magento\Framework\Setup\UpgradeSchemaInterface
{
    protected $resourceConfig;

    public function __construct(  
        \Magento\Framework\App\Config\ConfigResource\ConfigInterface $resourceConfig
    ) {
        $this->resourceConfig = $resourceConfig;
    }
    
    public function upgrade(
        \Magento\Framework\Setup\SchemaSetupInterface $setup, 
        \Magento\Framework\Setup\ModuleContextInterface $context
    ) {
        $installer = $setup;
        $installer->startSetup();


        if (version_compare($context->getVersion(), '1.0.2', '<=')) {
            $this->resourceConfig->deleteConfig(
                'payment/octifi/order_status',
                \Magento\Framework\App\Config\ScopeConfigInterface::SCOPE_TYPE_DEFAULT, 
                \Magento\Store\Model\Store::DEFAULT_STORE_ID
            );
        }
        if (version_compare($context->getVersion(), '1.0.3', '<=')) {
            $this->resourceConfig->deleteConfig(
                'payment/octifi/order_status2',
                \Magento\Framework\App\Config\ScopeConfigInterface::SCOPE_TYPE_DEFAULT, 
                \Magento\Store\Model\Store::DEFAULT_STORE_ID
            );
        }
    }
}