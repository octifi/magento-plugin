magento2-octifi
======================

Octifi payment gateway Magento2 extension

Install
=======

1. Upload code to folder app/code/Octifi/Octifi

2.  Enter following commands to install module:
    php bin/magento setup:upgrade
    php bin/magento setup:static-content:deploy

4. Enable and configure Octifi in Magento Admin under Stores -> Configuration-> Sales -> Payment Methods -> Octifi
