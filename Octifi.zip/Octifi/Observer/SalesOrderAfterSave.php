<?php

namespace Octifi\Octifi\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class SalesOrderAfterSave implements ObserverInterface {

    public function execute(Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
        if ($order instanceof \Magento\Framework\Model\AbstractModel) {
            if($order->getState() == 'complete') {
                $payment = $order->getPayment();
                $method = $payment->getMethodInstance()->getCode();
                if ($method == 'octifi') {
                    $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                    $dir = $objectManager->get('Magento\Framework\Module\Dir');
                    $base = $dir->getDir('Octifi_Octifi');
                    $lib_path = $base.'/vendor/octifienv/';
                    $lib_file = $lib_path.'loader.php';
                    include_once($lib_file);
                    
                    
                    $model = $objectManager->get('Octifi\Octifi\Model\Pay');
                    $helper = $objectManager->get('Octifi\Octifi\Helper\Data');
                    $messageManager = $objectManager->get('\Magento\Framework\Message\ManagerInterface');
                    
                    $order_response = $helper->getTransaction($order->getId());
                    if (!$order_response) {
                        $message = 'Octifi Capture attempted failed. Since Octifi Charge ID not available for this order';
                        $messageManager->addError($message);
                        return $this;
                    }

                    $gatewayResponse = json_decode($order_response, true);
                    
                    if (!isset($gatewayResponse['OctiFi_Charge_Id'])) {
                        $message = 'Octifi Capture attempted failed. Since Octifi Charge ID not available for this order';
                        $messageManager->addError($message);
                        return $this;
                    }
                    
                    $OctiFi_Charge_Id = $gatewayResponse['OctiFi_Charge_Id'];
                    $OctiFi_Payment_Action = '';
                    if (isset($gatewayResponse['OctiFi_Payment_Action'])) {
                        $OctiFi_Payment_Action = $gatewayResponse['OctiFi_Payment_Action'];
                    }
                    
                    $OctiFi_Captured = 0;
                    if (isset($gatewayResponse['OctiFi_Captured'])) {
                        $OctiFi_Captured = $gatewayResponse['OctiFi_Captured'];
                    }

                    if ($OctiFi_Payment_Action == 'capture') {
                        return $this;
                    }
                    
                    if ($OctiFi_Captured == 1) {
                        return $this;
                    }
                    
                    $header = array(
                        "accept: application/json",
                        "Content-Type: application/json",
                        "Authorization: Api-Key ".$model->getConfigValue('private_api_key')
                    );
                    
                    $params = array(
                        "charge_id" => $OctiFi_Charge_Id
                    );

                    $options2 = array(
                        CURLOPT_URL => $_OCTIFI_ENV['OCTIFI_CHARGE_URL'], 
                        CURLOPT_RETURNTRANSFER => true, 
                        CURLOPT_HEADER => false, 
                        CURLOPT_SSL_VERIFYPEER => false, 
                        CURLOPT_POST => true, 
                        CURLOPT_POSTFIELDS => json_encode($params), 
                        CURLOPT_HTTPHEADER => $header
                    );

                    $ch2 = curl_init();
                    curl_setopt_array($ch2, $options2);
                    $response3 = curl_exec($ch2);

                    if (!$response3) {
                        $error_message = curl_error($ch2);
                        $message = 'Octifi Capture attempted failed. Error from gateway:'.$error_message;
                        $messageManager->addError($message);
                        curl_close($ch2);
                    } else {
                        curl_close($ch2);
                        $result2 = json_decode($response3, true);
                        $model->log($options2);
                        $model->log($result2);
                        if ($result2['status_code'] == 200) {
                            $charge_status = $result2['data']['ChargeStatus'];
                            $comment = __('Payment successful with OctiFi(Captured). Charge Status: '.$charge_status);
                            $capture_status = 1;
                            $gatewayResponse['OctiFi_Captured'] = $capture_status;
                            $gatewayResponseJson = json_encode($gatewayResponse);                    
                            $helper->updateTransaction($order->getId(), $gatewayResponseJson);

                            $order->addStatusHistoryComment($comment);
                            $messageManager->addSuccess($comment);
                        } else {
                            $error_message = $result2['message'].'. '.$result2['errors']['non_field_errors'][0];
                            $message = 'Octifi Capture attempted failed. Error from gateway:'.$error_message;
                            $messageManager->addError($message);
                        }
                    }
                }
            }
        }
        return $this;
    }
}
