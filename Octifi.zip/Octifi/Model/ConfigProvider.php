<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Octifi\Octifi\Model;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\Escaper;
use Magento\Payment\Helper\Data as PaymentHelper;

class ConfigProvider implements ConfigProviderInterface
{
    /**
     * @var string[]
     */
    protected $methodCodes = [
        'octifi'
    ];

    /**
     * @var \Magento\Payment\Model\Method\AbstractMethod[]
     */
    protected $methods = [];

    /**
     * @var Escaper
     */
    protected $escaper;

    /**
     * @param PaymentHelper $paymentHelper
     * @param Escaper $escaper
     */
    public function __construct(
        PaymentHelper $paymentHelper,
        Escaper $escaper
    ) {
        $this->escaper = $escaper;
        foreach ($this->methodCodes as $code) {
            $this->methods[$code] = $paymentHelper->getMethodInstance($code);
        }
    }

    /**
     * {@inheritdoc}
     */
    public function getConfig()
    {
        $config = [];

        foreach ($this->methodCodes as $code) {
            if ($this->methods[$code]->isAvailable()) {
                $config['payment']['instructions'][$code] = $this->getInstructions($code);
                $config['payment'][$code]['redirectUrl'] = $this->methods[$code]->getCheckoutRedirectUrl();
                $config['payment'][$code]['redirectUrl'] = $this->methods[$code]->getCheckoutRedirectUrl();
                $config['payment'][$code]['installment_text'] = $this->getIstallmentText();
            }
        }
        return $config;
    }

    /**
     * Get instructions text from config
     *
     * @param string $code
     * @return string
     */
    protected function getInstructions($code)
    {
        return nl2br($this->escaper->escapeHtml($this->methods[$code]->getInstructions()));
    }

    /**
     * Get instructions text from config
     *
     * @param string $code
     * @return string
     */
    protected function getIstallmentText()
    {
        $objectManager   = \Magento\Framework\App\ObjectManager::getInstance();
        $checkoutSession = $objectManager->get('\Magento\Checkout\Model\Session'); 
        $grandTotal      = $checkoutSession->getQuote()->getGrandTotal();
        $priceHelper     = $objectManager->create('Magento\Framework\Pricing\PriceCurrencyInterface');
        $formattedPrice  = $priceHelper->convertAndFormat(round($grandTotal/3));
        $assetRepository = $objectManager->create('\Magento\Framework\View\Asset\Repository');
        $fileId = 'Octifi_Octifi::images/logo.jpeg';
        
        $model = $objectManager->create('\Octifi\Octifi\Model\Pay');
        $selected_country = $model->getConfigValue('new_payment_country');
        
        $html = '<p class="checkout-text-octifi">3 payments of <span id="checkout-newpayment">'.$formattedPrice.'</span>  or lower in <span class="learn-more learn">6 or 12 payments</span> with <img src="'.$assetRepository->getUrl($fileId).'" style="width:140px; margin: 0px auto;vertical-align: middle;"></p><br/>';
        return $html;
    }
}
