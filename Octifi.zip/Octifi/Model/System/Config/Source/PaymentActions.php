<?php

namespace Octifi\Octifi\Model\System\Config\Source;

class PaymentActions implements \Magento\Framework\Option\ArrayInterface {

    public function toOptionArray() {
        return [
                ['value' => 'authorise', 'label' => __('Authorization')],
                ['value' => 'capture', 'label' => __('Authorise & Capture')],
        ];
    }
}
