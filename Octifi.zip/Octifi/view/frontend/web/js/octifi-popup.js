require([
  'jquery',
  'jquery/ui'
], function($){

var mediaUrl = '/pub/media/octifi/';
/*jQuery(`.catalog-product-view .bundle-actions`).prepend(`<p class="octifi-p">3 payments of $${parseInt(parseInt(jQuery('.product-info-price .price-wrapper').attr('data-price-amount')) / 3)} with <img width="50" height="15" src="https://wordpress-529961-1688531.cloudwaysapps.com/wp-content/plugins/woocommerce-evgen/assets/images/logo.png"><a class="learn-more" href="#modal">Learn more</a></p>`)
jQuery(`.catalog-product-view .product-add-form`).prepend(`<p class="octifi-p">3 payments of $${parseInt(parseInt(jQuery('.product-info-price .price-wrapper').attr('data-price-amount')) / 3)} with <img width="50" height="15" src="https://wordpress-529961-1688531.cloudwaysapps.com/wp-content/plugins/woocommerce-evgen/assets/images/logo.png"><a class="learn-more" href="#modal">Learn more</a></p>`)
jQuery('.page-product-bundle .bundle-actions').prepend(`<p class="octifi-p">3 payments of $${parseInt(parseInt(jQuery('.product-info-price .price-wrapper').attr('data-price-amount')) / 3)} with <img width="50" height="15" src="https://wordpress-529961-1688531.cloudwaysapps.com/wp-content/plugins/woocommerce-evgen/assets/images/logo.png"><a class="learn-more" href="#modal">Learn more</a></p>`)
jQuery(`.page-product-grouped .price-wrapper:not([id*="from"])`).each(function() {jQuery(this).append(`<p class="price-text"> 3 payments of $${parseInt(jQuery(this).attr('data-price-amount') / 3)} with <img width="50" height="15" src="https://wordpress-529961-1688531.cloudwaysapps.com/wp-content/plugins/woocommerce-evgen/assets/images/logo.png"><a class="learn-more" href="#modal">Learn more</a></p>`)})
jQuery(`.catalog-product-view .product-add-form`).prepend(`<p class="octifi-p">3 payments of $${parseInt(parseInt(jQuery('.product-info-price .price-wrapper').text().replace('$','')) / 3)} with <img width="50" height="15" src="https://wordpress-529961-1688531.cloudwaysapps.com/wp-content/plugins/woocommerce-evgen/assets/images/logo.png"><a class="learn-more" href="#modal">Learn more</a></p>`)
*/


/*jQuery('.product-custom-option').on('change', function() {
  jQuery(`.catalog-product-view .product-add-form p`).remove()
  jQuery(`.catalog-product-view .product-add-form`).prepend(`<p class="octifi-p">3 payments of $${parseInt(parseInt(jQuery('.product-info-price .price-wrapper').text().replace('$','')) / 3)} with <img width="50" height="15" src="https://wordpress-529961-1688531.cloudwaysapps.com/wp-content/plugins/woocommerce-evgen/assets/images/logo.png"><a class="learn-more" href="#modal">Learn more</a></p>`)
})*/


//jQuery(`.page-products .price-wrapper:not([id*="from"])`).each(function() {jQuery(this).append(`<p class="price-text"> 3 payments of $${parseInt(jQuery(this).attr('data-price-amount') / 3)} with <img width="50" height="15" src="https://wordpress-529961-1688531.cloudwaysapps.com/wp-content/plugins/woocommerce-evgen/assets/images/logo.png"></p>`)})
/*var counter = 1;

  setInterval(function() {
    if(jQuery("#abayaja").length > 0 && counter == 1)
    {
      $('#abayaja').append(`<div><h2>Octifi Payment</h2><p class="octifi-p">3 payments of $${$('.table-totals .totals.sub .price').text().split('$')[1]} with <img width="50" height="15" src="https://wordpress-529961-1688531.cloudwaysapps.com/wp-content/plugins/woocommerce-evgen/assets/images/logo.png"><a class="learn-more">Learn more</a></p></div>`);    
      counter++;
    }

  },300);*/
  

  $('body').prepend(`<style>p.octifi-p+p.octifi-p{display:none}.payment-method-content a{display:block;margin-top:10px;}.bundle-actions p{margin: 10px 0;}.bundle-actions a{display:block;margin-top:10px;}.price-text{margin: 10px 0;}.price-text img{display:block; margin-top:10px;}.modal-ocitifi, .modal-ocitifi * {box-sizing: border-box;} .octify-modal-backdrop.show{opacity:.5}.octify-modal-backdrop.fade{opacity:0}.fade.show{opacity:.2}.octify-modal-backdrop{position:fixed;top:0;right:0;bottom:0;left:0;z-index:9991071;background-color:#000}.fade{opacity:0;transition:opacity .15s linear}.popup-overlay{font-family:'Montserrat',sans-serif;visibility:hidden;position:absolute;transform:translate(-50%,-50%) translateY(-15%);background:#fff;border:none;width:100%;margin:0 auto;height:auto;box-shadow:0 1px 7px -3px #585858;border-radius:100px;z-index:10;padding:30px;transition:transform .3s ease-in}.modal-ocitifi{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:999;height:84vh;max-width:586px;width:100%;opacity:0;display:none;overflow-x:hidden;overflow-y:auto}.modal-ocitifi.show{display:block;opacity:1;visibility:visible}.moda-ocitifi-dialog{min-height:100%;display:flex;align-items:center;justify-content:center;width:100%}.popup-overlay.active{visibility:visible;text-align:center;transform:translate(-50%,-50%) translateY(0);transition:transform .3s ease-in}.popup-content{visibility:hidden}.popup-content.active{visibility:visible}button{display:inline-block;vertical-align:middle;border-radius:30px;margin:.2rem;font-size:1rem;color:#666;background:#fff;border:1px solid #666}button:hover{border:1px solid #666;background:#666;color:#fff}.top-head-image img{max-width:100%;width:225px;margin-bottom:0}h5.head-title{margin:0!important;padding:0;font-family:'Montserrat',sans-serif;color:#000;letter-spacing:0;text-transform:unset;font-size:18px;font-weight:600}.top-head-image h5.head-title{max-width:60%;margin:10px auto 0!important;display:block;text-align:center;font-family:'Montserrat',sans-serif;color:#000;letter-spacing:0}.checkout-text-octifi{margin-bottom:0}p#OpenDialog{color:#35b0e4;cursor:pointer}.cstm-row{display:flex;align-items:flex-start;flex-wrap:wrap;margin-left:-15px;margin-right:-15px;padding:0 10px}.checkout-card img{width:57%}.cstm-row .cstm-col{flex:0 0 33%;max-width:33%;padding-left:15px;padding-right:15px}.checkout-card h6{margin:0;padding:0;max-width:65%;margin:0 auto 0!important;display:block;text-align:center;font-family:'Montserrat',sans-serif;color:#000;font-size:16px;min-height:70px;letter-spacing:0}.checkout-card p{color:black;font-size:14px;font-family: 'roboto', sans-serif!important;}.both-debit p{max-width:90%;margin:0 auto}.checkout-card p b{color:#000;font-family: 'roboto', sans-serif!important;}ul.payment-img{list-style:none;margin:0 0 20px;padding:0}ul.payment-img li{display:inline-block;width:13%}ul.payment-img li img{width:60px;vertical-align:middle}ul.payment-img li.american-img img{width:45px}.footer-title{margin-top:20px}.footer-title h5.head-title{font-size:18px;margin-bottom:10px!important}.both-debit p{max-width:90%;margin:0 auto}.footer-title h5.head-title{font-size:18px;margin-bottom:10px!important}.footer-title{margin-top:20px}.link-footer p{font-size:13px;color:#000;font-family:'Montserrat',sans-serif;line-height:1.3;margin-bottom:0}a.learn-more {color: #006aff!important;}.link-footer p a{display:block;text-decoration-color:#000;color:#006aff!important;font-weight:500;border:none!important;box-shadow:none}.link-footer p a:hover{box-shadow:none!important}.link-footer p a:focus{outline:none;box-shadow:none}.modal-ocitifi .moda-ocitifi-dialog .popup-overlay .popup-content .close-btn{position:absolute;right:20px;top:20px;color:#000!important;background:#d1d1d1;display:inline-block;width:30px;height:30px;line-height:30px;border-radius:100px;font-weight:700}.modal-ocitifi{z-index:9991072}.modal-ocitifi .moda-ocitifi-dialog .popup-overlay .popup-content{position:relative}body.popup-new{overflow:hidden}.payment_method_octifi img{width:100px}@media (max-width: 1200px){.popup-overlay{width:100%;max-width:600px}ul.payment-img li{display:inline-block;width:16%}}@media(max-width:767px){.modal-ocitifi{overflow:hidden;max-width:calc(100% - 7%)!important;max-height:100%;height:100vh;padding:15px 0}.modal-ocitifi .moda-ocitifi-dialog{min-height:auto!important;height:100%}.modal-ocitifi .moda-ocitifi-dialog .popup-overlay{top:0!important;transform:none;transform:none;position:initial!important;overflow:hidden;max-height:100%;border-radius:8px;padding:0;height:100%}.modal-ocitifi .moda-ocitifi-dialog .popup-overlay .popup-content{max-height:calc(100vh - 30px);overflow-y:auto;overflow-x:hidden;padding-top:30px;padding-bottom:30px}.modal-ocitifi{margin:0;max-width:80%;margin:0 auto}.modal-ocitifi .popup-overlay{margin:0;max-width:100%}.modal-ocitifi .moda-ocitifi-dialog .modal-content-wrap{height:100%}}@media (max-width: 575px){.popup-overlay{width:100%;max-width:85%;padding:25px 15px;border-radius:70px}.cstm-row .cstm-col{flex:0 0 100%;max-width:100%}.top-head-image h5.head-title{max-width:75%}.checkout-card h6{margin:0 auto 7px!important;min-height:auto}ul.payment-img li{width:20%}.checkout-card p{max-width:80%;margin:0 auto}.modal-ocitifi.show .popup-overlay.active{top:100%}}@media (max-width: 480px){.top-head-image h5.head-title{max-width:90%}.checkout-card p{max-width:90%}.checkout-card img{width:40%}}@media (max-width: 420px){.top-head-image h5.head-title,.checkout-card p{max-width:100%}h5.head-title{font-size:16px}ul.payment-img li{width:30%}.top-head-image img{width:120px}} .octify-modal-overlay {position: fixed;top: 0;left: 0;width: 100%;height: 100%;z-index: 9;background-color: #000;opacity:.5;}</style>`);
  $('body').append(`<div class="modal-ocitifi">
  <div class="moda-ocitifi-dialog">
    <div class="modal-content-wrap">
      <div class="popup-overlay active">
        <!--Creates the popup content-->
        <div class="popup-content active">
          <a href="#" class="close-btn">X</a>
          <div class="top-head-image">
            <img
              src="`+mediaUrl+`latitude.png"
              class="img-fluid"
              alt="logo"
            />
            <h5 class="head-title">
              Be the savvy customer and choose LatitudePay  at checkout
            </h5>
          </div>
          <div class="cstm-row">
            <div class="cstm-col">
              <div class="checkout-card">
                <img
                  src="`+mediaUrl+`Pay-only-1_3-today-icon.gif"
                  class="img-fluid"
                  alt="card-img"
                />
                <h6>Pay only 1/3 today</h6>
                <p>
                  We pay the store full, and you pay us in 3 instalment,
                  <b>0% interest with no hidden fees</b>
                </p>
              </div>
            </div>

            <div class="cstm-col">
              <div class="checkout-card both-debit">
                <img
                  src="`+mediaUrl+`Usebothcreditn debitcard.gif"
                  class="img-fluid"
                  alt="card-img"
                />
                <h6>Use both debit or credit card</h6>
                <p>
                  No credit card? No problem! We accept any Singapore Banks
                  issue debit cards.
                </p>
              </div>
            </div>

            <div class="cstm-col">
              <div class="checkout-card">
                <img
                  src="`+mediaUrl+`Earncashbackicon.gif"
                  class="img-fluid"
                  alt="card-img"
                />
                <h6>Earn 1.5% cashback</h6>
                <p>
                  Have more cash to spare? Pay more upfront and earn additional
                  1.5% cashback from us!
                </p>
              </div>
            </div>
          </div>
          <div class="footer-title">
            <h5 class="head-title">Pay with your preferred payment methods</h5>
            <ul class="payment-img">
              <li>
                <img
                  src="`+mediaUrl+`visa.png"
                />
              </li>
              <li>
                <img
                  src="`+mediaUrl+`mastercard.png"
                />
              </li>
              <li class="american-img">
                <img
                  src="`+mediaUrl+`American-express.png"
                />
              </li>
            </ul>
            <div class="link-footer">
              <p>
                Terms and Condition Applies.<a target="_blank"
                  href="https://octifi.com/paylater_terms/"
                  style="text-decoration: none;">See full T &amp; C here &gt;&gt;</a
                >
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div><div class="octify-modal-overlay"></div>`);
  
  $('body').prepend(`<style>p.octifi-p+p.octifi-p{display:none}.payment-method-content a{display:block;margin-top:10px;}.bundle-actions p{margin: 10px 0;}.bundle-actions a{display:block;margin-top:10px;}.price-text{margin: 10px 0;}.price-text img{display:block; margin-top:10px;}.modal-ocitifimy, .modal-ocitifimy * {box-sizing: border-box;} .octify-modal-backdrop.show{opacity:.5}.octify-modal-backdrop.fade{opacity:0}.fade.show{opacity:.2}.octify-modal-backdrop{position:fixed;top:0;right:0;bottom:0;left:0;z-index:9991071;background-color:#000}.fade{opacity:0;transition:opacity .15s linear}.popup-overlay{font-family:'Montserrat',sans-serif;visibility:hidden;position:absolute;transform:translate(-50%,-50%) translateY(-15%);background:#fff;border:none;width:100%;margin:0 auto;height:auto;box-shadow:0 1px 7px -3px #585858;border-radius:100px;z-index:10;padding:30px;transition:transform .3s ease-in}.modal-ocitifimy{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:999;height:84vh;max-width:586px;width:100%;opacity:0;display:none;overflow-x:hidden;overflow-y:auto}.modal-ocitifimy.show{display:block;opacity:1;visibility:visible}.moda-ocitifi-dialog{min-height:100%;display:flex;align-items:center;justify-content:center;width:100%}.popup-overlay.active{visibility:visible;text-align:center;transform:translate(-50%,-50%) translateY(0);transition:transform .3s ease-in}.popup-content{visibility:hidden}.popup-content.active{visibility:visible}button{display:inline-block;vertical-align:middle;border-radius:30px;margin:.2rem;font-size:1rem;color:#666;background:#fff;border:1px solid #666}button:hover{border:1px solid #666;background:#666;color:#fff}.top-head-image img{max-width:100%;width:225px;margin-bottom:0}h5.head-title{margin:0!important;padding:0;font-family:'Montserrat',sans-serif;color:#000;letter-spacing:0;text-transform:unset;font-size:18px;font-weight:600}.top-head-image h5.head-title{max-width:60%;margin:10px auto 0!important;display:block;text-align:center;font-family:'Montserrat',sans-serif;color:#000;letter-spacing:0}.checkout-text-octifi{margin-bottom:0}p#OpenDialog{color:#35b0e4;cursor:pointer}.cstm-row{display:flex;align-items:flex-start;flex-wrap:wrap;margin-left:-15px;margin-right:-15px;padding:0 10px}.checkout-card img{width:57%}.cstm-row .cstm-col{flex:0 0 33%;max-width:33%;padding-left:15px;padding-right:15px}.checkout-card h6{margin:0;padding:0;max-width:65%;margin:0 auto 0!important;display:block;text-align:center;font-family:'Montserrat',sans-serif;color:#000;font-size:16px;min-height:70px;letter-spacing:0}.checkout-card p{color:black;font-size:14px;font-family: 'roboto', sans-serif!important;}.both-debit p{max-width:90%;margin:0 auto}.checkout-card p b{color:#000;font-family: 'roboto', sans-serif!important;}ul.payment-img{list-style:none;margin:0 0 20px;padding:0}ul.payment-img li{display:inline-block;width:13%}ul.payment-img li img{width:60px;vertical-align:middle}ul.payment-img li.american-img img{width:45px}.footer-title{margin-top:20px}.footer-title h5.head-title{font-size:18px;margin-bottom:10px!important}.both-debit p{max-width:90%;margin:0 auto}.footer-title h5.head-title{font-size:18px;margin-bottom:10px!important}.footer-title{margin-top:20px}.link-footer p{font-size:13px;color:#000;font-family:'Montserrat',sans-serif;line-height:1.3;margin-bottom:0}a.learn-more {color: #006aff!important;}.link-footer p a{display:block;text-decoration-color:#000;color:#006aff!important;font-weight:500;border:none!important;box-shadow:none}.link-footer p a:hover{box-shadow:none!important}.link-footer p a:focus{outline:none;box-shadow:none}.modal-ocitifimy .moda-ocitifi-dialog .popup-overlay .popup-content .close-btn{position:absolute;right:20px;top:20px;color:#000!important;background:#d1d1d1;display:inline-block;width:30px;height:30px;line-height:30px;border-radius:100px;font-weight:700}.modal-ocitifimy{z-index:9991072}.modal-ocitifimy .moda-ocitifi-dialog .popup-overlay .popup-content{position:relative}body.popup-new{overflow:hidden}.payment_method_octifi img{width:100px}@media (max-width: 1200px){.popup-overlay{width:100%;max-width:600px}ul.payment-img li{display:inline-block;width:16%}}@media(max-width:767px){.modal-ocitifimy{overflow:hidden;max-width:calc(100% - 7%)!important;max-height:100%;height:100vh;padding:15px 0}.modal-ocitifimy .moda-ocitifi-dialog{min-height:auto!important;height:100%}.modal-ocitifimy .moda-ocitifi-dialog .popup-overlay{top:0!important;transform:none;transform:none;position:initial!important;overflow:hidden;max-height:100%;border-radius:8px;padding:0;height:100%}.modal-ocitifimy .moda-ocitifi-dialog .popup-overlay .popup-content{max-height:calc(100vh - 30px);overflow-y:auto;overflow-x:hidden;padding-top:30px;padding-bottom:30px}.modal-ocitifimy{margin:0;max-width:80%;margin:0 auto}.modal-ocitifimy .popup-overlay{margin:0;max-width:100%}.modal-ocitifimy .moda-ocitifi-dialog .modal-content-wrap{height:100%}}@media (max-width: 575px){.popup-overlay{width:100%;max-width:85%;padding:25px 15px;border-radius:70px}.cstm-row .cstm-col{flex:0 0 100%;max-width:100%}.top-head-image h5.head-title{max-width:75%}.checkout-card h6{margin:0 auto 7px!important;min-height:auto}ul.payment-img li{width:20%}.checkout-card p{max-width:80%;margin:0 auto}.modal-ocitifimy.show .popup-overlay.active{top:100%}}@media (max-width: 480px){.top-head-image h5.head-title{max-width:90%}.checkout-card p{max-width:90%}.checkout-card img{width:40%}}@media (max-width: 420px){.top-head-image h5.head-title,.checkout-card p{max-width:100%}h5.head-title{font-size:16px}ul.payment-img li{width:30%}.top-head-image img{width:120px}} .octify-modal-overlaymalaysia {position: fixed;top: 0;left: 0;width: 100%;height: 100%;z-index: 9;background-color: #000;opacity:.5;}</style>`);
  $('body').append(`<div class="my modal-ocitifimy">
  <div class="moda-ocitifi-dialog">
    <div class="modal-content-wrap">
      <div class="popup-overlay active" style="border-radius:50px !important;">
        <!--Creates the popup content-->
        <div class="popup-content active">
          <a href="#" class="close-btn" style="right:0 !important;top:0 !important;text-decoration: none !important;">X</a>
          <div class="top-head-image">
            <img
              src="`+mediaUrl+`latitude.png"
              class="img-fluid"
              alt="logo"
            />
            <h5 class="head-title">
              Be the savvy customer and choose LatitudePay  at checkout
            </h5>
          </div>
          <div class="cstm-row">
            <div class="cstm-col">
              <div class="checkout-card">
                <img
                  src="`+mediaUrl+`Pay-only-1_3-today-icon.gif"
                  class="img-fluid"
                  alt="card-img"
                />
                <h6>Pay only 1/3 today</h6>
                <p>
                  3 easy instalments, <b>0% interest with no hidden fees</b>
                </p>
              </div>
            </div>

            <div class="cstm-col">
              <div class="checkout-card both-debit">
                <img
                  src="`+mediaUrl+`Usebothcreditn debitcard.gif"
                  class="img-fluid"
                  alt="card-img"
                />
                <h6>Use both debit or credit card</h6>
                <p>
                   No credit card? No problem! We accept all major bank debit cards.
                </p>
              </div>
            </div>

            <div class="cstm-col">
              <div class="checkout-card">
                <img
                  src="`+mediaUrl+`Earncashbackicon.gif"
                  class="img-fluid"
                  alt="card-img"
                />
                <h6>Earn 1.5% cashback</h6>
                <p>
                  Have spare cash? Pay more upfront and earn additional 1.5% cashback!
                </p>
              </div>
            </div>
          </div>
          <div class="footer-title">
            <h5 class="head-title">Pay with your preferred payment methods</h5>
            <ul class="payment-img">
              <li>
                <img
                  src="`+mediaUrl+`visa.png"
                />
              </li>
              <li>
                <img
                  src="`+mediaUrl+`mastercard.png"
                />
              </li>
              <li class="american-img">
                <img
                  src="`+mediaUrl+`American-express.png"
                />
              </li>
            </ul>
            <div class="link-footer">
              <p>
                Terms and Condition Applies.<a target="_blank"
                  href="https://my.latitudepay.com/paylater_terms/"
                  style="text-decoration: none;">See full T&amp;C here &gt;&gt;</a
                >
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div><div class="octify-modal-overlaymalaysia"></div>`);
  $('.octify-modal-overlay').hide();
  $('.octify-modal-overlaymalaysia').hide();


  $('body').on('click', '.learn-more', function() {
      $('.modal-ocitifi').addClass('show');
      $('.octify-modal-overlay').show();
  });
  
  //malaysia
  $('body').on('click', '.learn-moremy', function() {
      $('.modal-ocitifimy').addClass('show');
      $('.octify-modal-overlaymalaysia').show();
  });


  $('body').on('click', '.close-btn', function() {
      $('.modal-ocitifi').removeClass('show');
      $('.octify-modal-overlay').hide();
  });

  //malaysisa
  $('body').on('click', '.close-btn', function() {
      $('.modal-ocitifimy').removeClass('show');
      $('.octify-modal-overlaymalaysia').hide();
  });

  $('body').on('click', '.octify-modal-overlay', function() {
      $('.modal-ocitifi').removeClass('show');
    $('.octify-modal-overlay').hide();
  });
  
  //malaysia
  $('body').on('click', '.octify-modal-overlaymalaysia', function() {
      $('.modal-ocitifimy').removeClass('show');
    $('.octify-modal-overlaymalaysia').hide();
  });


}); 
