<?php
namespace Octifi\Octifi\Controller\Index;

use Magento\Framework\Controller\ResultFactory;

class Callback extends \Magento\Framework\App\Action\Action
{
    protected $helper;
    protected $payment;
    protected $orderFactory;

    public function __construct(
        \Octifi\Octifi\Helper\Data $helper,
        \Octifi\Octifi\Model\Pay $payment,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Framework\App\Action\Context $context
    ) {
        $this->helper = $helper;
        $this->payment = $payment;
        $this->orderFactory = $orderFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $dir = $this->_objectManager->get('Magento\Framework\Module\Dir');
        $base = $dir->getDir('Octifi_Octifi');
        $lib_path = $base.'/vendor/octifienv/';
        $lib_file = $lib_path.'loader.php';
        include_once($lib_file);
        
        $params = $this->getRequest()->getParams();
        if (isset($params['data'])) {
            $data = $params['data'];
            $jsonData =  base64_decode($data);
            $response = json_decode($jsonData, true);
        } else {
            $response = $params;
        }
        
        $order_id = $response['merchant_order_id'];

        $order = $this->getOrder($order_id);
        
        $model = $this->_objectManager->get('Octifi\Octifi\Model\Pay');
        $session = $this->_objectManager->get('Magento\Checkout\Model\Session');
        
        $error_message = '';
        $additional_comment = '';
        
        if ($response['statuscode'] == 200) {
            $checkout_token = $response['checkout_token'];
            $header = array(
                "accept: application/json",
                "Content-Type: application/json",
                "Authorization: Api-Key ".$model->getConfigValue('private_api_key')
            );
            
                        
            $is_capture = false;
            if ($model->getConfigValue('new_payment_action') == 'capture') {
                $is_capture = true;
            }

            $params = array(
                "bill_total_amount" => $this->getFormattedAmount($order->getGrandTotal()),
                "bill_currency" => $order->getOrderCurrencyCode(),
                "bill_tax_amount" => $this->getFormattedAmount($order->getTaxAmount()), 
                "is_capture" => $is_capture
            );

            $options = array(
                CURLOPT_URL => $_OCTIFI_ENV['OCTIFI_CREATE_URL'].$checkout_token."/", 
                CURLOPT_RETURNTRANSFER => true, 
                CURLOPT_HEADER => false, 
                CURLOPT_SSL_VERIFYPEER => false, 
                CURLOPT_POST => true, 
                CURLOPT_POSTFIELDS => json_encode($params), 
                CURLOPT_HTTPHEADER => $header
            );

            $ch = curl_init();
            curl_setopt_array($ch, $options);
            $response2 = curl_exec($ch);

            if (!$response2) {
                $error_message = curl_error($ch);
                curl_close($ch);
            } else {
                curl_close($ch);
                $result = json_decode($response2, true);
                $model->log($options);
                $model->log($result);
                if ($result['status_code'] == 200) {
                   
                    $OctiFi_Charge_Id = $result['data']['charge_id'];
                    $OctiFi_Txn_Number = $result['data']['order_payment_details']['data']['txn_number'];
                    
                    $gatewayResponse['OctiFi_Charge_Id'] = $OctiFi_Charge_Id;
                    $gatewayResponse['OctiFi_Txn_Number'] = $OctiFi_Txn_Number;
                    $gatewayResponse['OctiFi_Payment_Action'] = $model->getConfigValue('new_payment_action');

                    $gatewayResponseJson = json_encode($gatewayResponse);                    
                    
                    $this->helper->updateTransaction($order->getId(), $gatewayResponseJson);
                    
                    if ($is_capture) {

                        $params = array(
                            "charge_id" => $OctiFi_Charge_Id
                        );

                        $options2 = array(
                            CURLOPT_URL => $_OCTIFI_ENV['OCTIFI_CHARGE_DETAIL_URL'].$OctiFi_Charge_Id."/", 
                            CURLOPT_RETURNTRANSFER => true, 
                            CURLOPT_HEADER => false, 
                            CURLOPT_SSL_VERIFYPEER => false, 
                            //CURLOPT_POST => true, 
                            //CURLOPT_POSTFIELDS => json_encode($params), 
                            CURLOPT_HTTPHEADER => $header
                        );

                        $ch2 = curl_init();
                        curl_setopt_array($ch2, $options2);
                        $response3 = curl_exec($ch2);

                        if (!$response3) {
                            $error_message = curl_error($ch2);
                            curl_close($ch2);
                        } else {
                            curl_close($ch2);
                            $result2 = json_decode($response3, true);
                            //print_r($result2);exit;
                            $model->log($options2);
                            $model->log($result2);
                            if ($result2['status_code'] == 200) {
                                $charge_status = $result2['data']['state'];
                                $comment = __('Payment successful with LatitudePay(Authorized and Captured). ');
                                $comment .= __('Checkout Token: '.$checkout_token.'. ');
                                $comment .= __('Charge ID: '.$OctiFi_Charge_Id.'. ');
                                $comment .= __('Charge Status: '.$charge_status.'. ');
                                $comment .= __('Transaction ID: '). $OctiFi_Txn_Number;
                                
                                if ($charge_status == 'ChargeState.CAPTURED') {
                                    $capture_status = 1;
                                }
                                $gatewayResponse['OctiFi_Captured'] = $capture_status;
                                $gatewayResponseJson = json_encode($gatewayResponse);                    
                                $this->helper->updateTransaction($order->getId(), $gatewayResponseJson);

                                $state = $model->getConfigValue('new_order_status');
                                if (empty($state)) {
                                    $state = \Magento\Sales\Model\Order::STATE_PROCESSING;
                                }
                                $status = $state;

                                $order->setState($state);
                                $order->setStatus($status);
                                $order->setTotalPaid($order->getGrandTotal());
                                $order->addStatusHistoryComment($comment, $status);
                                $order->save();
                                
                                //$this->_redirect('checkout/success');
                                echo '<script>window.top.location.href = "'.$model->getCheckoutSuccessUrl().'";</script>';
                            } else {
                                $error_message = $result2['message'].'. '.$result2['errors']['non_field_errors'][0];

                                $additional_comment = __('Checkout Token: '.$checkout_token.'. ');
                                $additional_comment .= __('Charge ID: '.$OctiFi_Charge_Id.'. ');
                                $additional_comment .= __('Transaction ID: '). $OctiFi_Txn_Number;
                            }
                        }
                    } else {
                        $charge_status = $result['data']['order_detail']['status'];
                        
                        $OctiFi_Charge_Id = 'Not created';
                        $OctiFi_Txn_Number = '';
                        
                        if (isset($result['data']['charge_id'])) {
                            $OctiFi_Charge_Id = $result['data']['charge_id'];
                            $gatewayResponse['OctiFi_Charge_Id'] = $OctiFi_Charge_Id;
                        }
                        
                        if (isset($result['data']['order_payment_details']['data']['txn_number'])) { 
                            $OctiFi_Txn_Number = $result['data']['order_payment_details']['data']['txn_number'];
                            $gatewayResponse['OctiFi_Txn_Number'] = $OctiFi_Txn_Number;
                        }
                        $gatewayResponseJson = json_encode($gatewayResponse);                    

                        $this->helper->updateTransaction($order->getId(), $gatewayResponseJson);
                        
                        $additional_comment = __('Checkout Token: '.$checkout_token.'. ');
                        $additional_comment .= __('Charge ID: '.$OctiFi_Charge_Id.'. ');
                        $additional_comment .= __('Transaction ID: '). $OctiFi_Txn_Number;
                        
                        $comment = __('Payment successful with OctiFi(Authorized). Charge Status: '.$charge_status.'. ');
                        $comment .= $additional_comment;

                        $state = $model->getConfigValue('new_order_status');
                        if (empty($state)) {
                            $state = \Magento\Sales\Model\Order::STATE_PROCESSING;
                        }
                        $status = $state;

                        $order->setState($state);
                        $order->setStatus($status);
                        $order->setTotalPaid($order->getGrandTotal());
                        $order->addStatusHistoryComment($comment, $status);
                        $order->save();
                        //$this->_redirect('checkout/success');
                        echo '<script>window.top.location.href = "'.$model->getCheckoutSuccessUrl().'";</script>';
                    }
                    
                } else {
                    $error_message = $result['message'].'. '.$result['errors']['non_field_errors'][0];
                    $additional_comment = __('Checkout Token: '.$checkout_token.'. ');
                    $OctiFi_Charge_Id = __('Not created');
                    if (isset($result['data']['charge_id'])) {
                        $OctiFi_Charge_Id = $result['data']['charge_id'];
                        $additional_comment .= __('Charge ID: '.$OctiFi_Charge_Id.'. ');
                    }
                }
            }
        } else {
            $error_message =  __('No Checkout Token from OctiFi');
        }

        if ($error_message) {
            $order->cancel();
            $message = __('Payment Failed with LatitudePay. Reason: '.$error_message);
            $order->addStatusHistoryComment($message.' '.$additional_comment, \Magento\Sales\Model\Order::STATE_CANCELED);
            $order->save();
            $session->restoreQuote();
            $this->messageManager->addError($message);
            //$this->_redirect('checkout/cart');
            echo '<script>window.top.location.href = "'.$model->getCheckoutCartUrl().'";</script>';
        }
        exit;
    }
    
    public function getOrder($Id) {
        $orderFactory = $this->orderFactory->create();
        return $orderFactory->loadByIncrementId($Id);
    }
    
    public function getFormattedAmount($amount) {
        return round($amount, 2);
    }
}
