<?php

namespace Octifi\Octifi\Controller\Index;

use Magento\Checkout\Model\Type\Onepage;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Quote\Api\CartManagementInterface;

class Cancel extends \Magento\Framework\App\Action\Action {

    /**
     * @var \Magento\Quote\Api\CartManagementInterface
     */
    protected $cartManagement;

    /**
     * @var \Magento\Framework\Event\ManagerInterface
     */
    protected $eventManager;

    /**
     * @var \Magento\Checkout\Model\Type\Onepage
     */
    protected $onepageCheckout;

    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @var \Magento\Authorizenet\Helper\DataFactory
     */
    protected $dataFactory;

    /**
     *
     * @var \Magento\Checkout\Model\Session
     */
    protected $session;

    /**
     *
     * @var \Magento\Sales\Model\OrderFactory
     */
    protected $orderFactory;

    /**
     *
     * @var Magento\Checkout\Model\Session
     */
    protected $_order;

    /**
     * 
     * @param Context $context
     * @param \Magento\Checkout\Model\Session $orderSession
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param \Magento\Checkout\Model\Session $session
     * @param Registry $coreRegistry
     * @param CartManagementInterface $cartManagement
     * @param Onepage $onepageCheckout
     */
    public function __construct(
        Context $context, 
        \Magento\Checkout\Model\Session $orderSession, 
        \Magento\Sales\Model\OrderFactory $orderFactory, 
        \Magento\Checkout\Model\Session $session, 
        Registry $coreRegistry, 
        CartManagementInterface $cartManagement, 
        Onepage $onepageCheckout
    ) {
        $this->eventManager = $context->getEventManager();
        $this->cartManagement = $cartManagement;
        $this->onepageCheckout = $onepageCheckout;
        $this->_coreRegistry = $coreRegistry;
        $this->session = $session;
        $this->orderFactory = $orderFactory;
        $this->_order = $orderSession;
        parent::__construct($context);
    }

    /**
     *
     * @return string
     */
    public function execute() {
        $params = $this->getRequest()->getParams();
        if (isset($params['data'])) {
            $data = $params['data'];
            $jsonData =  base64_decode($data);
            $response = json_decode($jsonData, true);
        } else {
            $response['errorcode'] = $params['errorcode'];
            $response['merchant_order_id'] = $params['merchant_order_id'];
            $response['statuscode'] = $params['statuscode'];
        }
        
        $model = $this->_objectManager->get('Octifi\Octifi\Model\Pay');

        $model->log('Cancel Action:');
        $model->log($response);
        $order_id = $response['merchant_order_id'];
        $order = $this->getOrder($order_id);

        $order->cancel();
        
        $error_message = $response['errorcode'][0];
        if ($error_message == 'C') {
            $error_message = $response['errorcode'];
        }
	$message = __('Payment Failed with OctiFi. Reason: '.$error_message);
        
        $checkout_token = __('No Checkout Token from OctiFi');
        if (isset($response['checkout_token'])) {
            $checkout_token = $response['checkout_token'];
        }
        $additional_comment = __('Checkout Token: '.$checkout_token.'. ');
        
        $order->addStatusHistoryComment($message.' '.$additional_comment, \Magento\Sales\Model\Order::STATE_CANCELED);
        $order->save();
        $this->session->restoreQuote();
	$this->messageManager->addError($message);
        //$this->_redirect('checkout/cart');
        echo '<script>window.top.location.href = "'.$model->getCheckoutCartUrl().'";</script>';
        exit;
    }

    /**
     * 
     * @return type
     */
    public function getOrder($Id) {
        $orderFactory = $this->orderFactory->create();
        return $orderFactory->loadByIncrementId($Id);
    }

    /**
     * Get Checkout Session
     * @return \Magento\Checkout\Model\Session
     */
    public function getCheckout() {
        return $this->_order;
    }
}
