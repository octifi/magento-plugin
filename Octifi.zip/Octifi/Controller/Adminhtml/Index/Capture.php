<?php
 
namespace Octifi\Octifi\Controller\Adminhtml\Index;
 
use Magento\Backend\App\Action;
 
class Capture extends Action

{
    protected function _isAllowed()
    {
        return true;
    }
    
    public function execute()
    {
       $params = $this->getRequest()->getParams();
       $order_id = (int)$params['order_id'];
       if ($order_id > 0) {
           $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
           $order = $objectManager->get('Magento\Sales\Model\Order')->load($order_id);
            if ($order instanceof \Magento\Framework\Model\AbstractModel) {
                $payment = $order->getPayment();
                $method = $payment->getMethodInstance()->getCode();
                if ($method == 'octifi') {
                    $dir = $objectManager->get('Magento\Framework\Module\Dir');
                    $base = $dir->getDir('Octifi_Octifi');
                    $lib_path = $base.'/vendor/octifienv/';
                    $lib_file = $lib_path.'loader.php';
                    include_once($lib_file);


                    $model = $objectManager->get('Octifi\Octifi\Model\Pay');
                    $helper = $objectManager->get('Octifi\Octifi\Helper\Data');
                    $messageManager = $objectManager->get('\Magento\Framework\Message\ManagerInterface');

                    $order_response = $helper->getTransaction($order->getId());
                    if (!$order_response) {
                        $message = 'LatitudePay Capture attempted failed. Since LatitudePay Charge ID not available for this order';
                        $messageManager->addError($message);
                        $this->_redirect('sales/order/view', ['order_id' => $order_id]);
                    }

                    $gatewayResponse = json_decode($order_response, true);

                    if (!isset($gatewayResponse['OctiFi_Charge_Id'])) {
                        $message = 'LatitudePay Capture attempted failed. Since LatitudePay Charge ID not available for this order.';
                        $messageManager->addError($message);
                        $this->_redirect('sales/order/view', ['order_id' => $order_id]);
                    }

                    $OctiFi_Charge_Id = $gatewayResponse['OctiFi_Charge_Id'];
                    
                    $OctiFi_Captured = 0;
                    if (isset($gatewayResponse['OctiFi_Captured'])) {
                        $OctiFi_Captured = $gatewayResponse['OctiFi_Captured'];
                    }

                    if ($OctiFi_Captured == 1) {
                        $message = 'This LatitudePay charge has already been captured.';
                        $messageManager->addError($message);
                        $this->_redirect('sales/order/view', ['order_id' => $order_id]);
                    }

                    $header = array(
                        "accept: application/json",
                        "Content-Type: application/json",
                        "Authorization: Api-Key ".$model->getConfigValue('private_api_key')
                    );

                    $params = array(
                        "charge_id" => $OctiFi_Charge_Id
                    );

                    $options2 = array(
                        CURLOPT_URL => $_OCTIFI_ENV['OCTIFI_CHARGE_URL'], 
                        CURLOPT_RETURNTRANSFER => true, 
                        CURLOPT_HEADER => false, 
                        CURLOPT_SSL_VERIFYPEER => false, 
                        CURLOPT_POST => true, 
                        CURLOPT_POSTFIELDS => json_encode($params), 
                        CURLOPT_HTTPHEADER => $header
                    );

                    $ch2 = curl_init();
                    curl_setopt_array($ch2, $options2);
                    $response3 = curl_exec($ch2);

                    if (!$response3) {
                        $error_message = curl_error($ch2);
                        $message = 'LatitudePay Capture attempted failed. Error from gateway:'.$error_message;
                        $messageManager->addError($message);
                        curl_close($ch2);
                        $this->_redirect('sales/order/view', ['order_id' => $order_id]);
                    } else {
                        curl_close($ch2);
                        $result2 = json_decode($response3, true);
                        $model->log($options2);
                        $model->log($result2);
                        if ($result2['status_code'] == 200) {
                            $message = $result2['message'];
                            if($message == 'This charge has already been captured') {
                                $message = 'This LatitudePay charge has already been captured';
                                $messageManager->addError($message);
                                $this->_redirect('sales/order/view', ['order_id' => $order_id]);
                            } else {
                                $charge_status = $result2['data']['ChargeStatus'];
                                $comment = __('Payment successful with LatitudePay(Captured). Charge Status: '.$charge_status);
                                $capture_status = 1;
                                $gatewayResponse['OctiFi_Captured'] = $capture_status;
                                $gatewayResponseJson = json_encode($gatewayResponse);                    
                                $helper->updateTransaction($order->getId(), $gatewayResponseJson);

                                $order->addStatusHistoryComment($comment);
                                $messageManager->addSuccess($comment);
                                $this->_redirect('sales/order/view', ['order_id' => $order_id]);
                            }
                        } else {
                            if (isset($result2['message']['errors_code'])) {
                                $error_message = $result2['message']['errors_code'];
                                if ($error_message == 'ALREADY_CAPTURED') {
                                    $capture_status = 1;
                                    $gatewayResponse['OctiFi_Captured'] = $capture_status;
                                    $gatewayResponseJson = json_encode($gatewayResponse);                    
                                    $helper->updateTransaction($order->getId(), $gatewayResponseJson);
                                }
                            } else {
                                $error_message = $result2['message'].'. '.$result2['errors']['non_field_errors'][0];
                            }
                            $message = 'LatitudePay Capture attempted failed. Error from gateway: '.$error_message;
                            $messageManager->addError($message);
                            $this->_redirect('sales/order/view', ['order_id' => $order_id]);
                        }
                    }
                } else {//not the octifi method
                    $message = 'This order was not paid with LatitudePay payment method.';
                    $messageManager->addError($message);
                    $this->_redirect('sales/order/view', ['order_id' => $order_id]);
                }
            } else {//order not exist
                $message = 'This order does not exist.';
                $messageManager->addError($message);
                $this->_redirect('sales/order/view', ['order_id' => $order_id]);
            }
        } else {//order id not valid
            $message = 'Invalid Order Id. Get Lost.';
            echo $message; 
            exit;
        }
    }
}
