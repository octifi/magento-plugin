<?php

namespace Octifi\Octifi\Block;

class Pay extends \Magento\Framework\View\Element\Template
{
    protected $sessionCustomer;
    protected $request;
    protected $response;
    protected $messageManager;

    public function __construct(
        \Magento\Catalog\Block\Product\Context $context, 
        \Magento\Customer\Model\Session $sessionCustomer, 
        \Magento\Framework\App\Response\Http $response,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        array $data = []) {

        parent::__construct($context, $data);
        $this->sessionCustomer = $sessionCustomer;
        $this->request = $context->getRequest();
        $this->response = $response;
        $this->messageManager = $messageManager;
    }
	
    public function getCacheLifetime() {
        return null;
    }
	
    public function getCancelUrl() {
	$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $model = $objectManager->create('\Octifi\Octifi\Model\Pay');
        return $model->getCancelUrl();
    }
	
    public function getCallbackUrl() {
	$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $model = $objectManager->create('\Octifi\Octifi\Model\Pay');
        return $model->getCallbackUrl();
    }
	
    public function getCheckout() {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        return $objectManager->create('\Magento\Checkout\Model\Session');
    }

    public function getOrder() {
        return $this->getCheckout()->getLastRealOrder();
    }

    public function getConfiguration() {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        
        $dir = $objectManager->get('Magento\Framework\Module\Dir');
        $base = $dir->getDir('Octifi_Octifi');
        $lib_path = $base.'/vendor/octifienv/';
        $lib_file = $lib_path.'loader.php';
        include_once($lib_file);
        
        $configs = array();
        
        $model = $objectManager->create('\Octifi\Octifi\Model\Pay');

        $logo = $objectManager->get('\Magento\Theme\Block\Html\Header\Logo');
        $logo_src = $logo->getLogoSrc();

        $order = $this->getOrder();

        if (!$order || $order->getId() < 1) {
            echo '<script>window.top.location.href = "'.$this->getUrl('checkout/cart').'";</script>';
            exit;
        }

        $product_name = '';
        foreach ($order->getAllItems() as $item) {
            $product_name .= $item->getName();; 
        }

        $amount = $order->getGrandTotal();
        $shoppingCartId = $order->getIncrementId();

        $address = implode (",", $order->getBillingAddress()->getStreet());

        $configs['api_key'] = $model->getConfigValue('api_key');
        $configs['payment_type'] = $model->getConfigValue('payment_type');
        $configs['logo_src'] = $logo_src;

        $merchant_name = $model->getConfigValue('merchant_name');
        if (empty($merchant_name)) {
            $merchant_name = $model->getStoreName();
        }
        $configs['site_name'] = $merchant_name;

        $configs['product_name'] = $product_name;
        $configs['total_amount'] = $this->getFormattedAmount($order->getGrandTotal());
        $configs['tax_amount'] = $this->getFormattedAmount($order->getTaxAmount());
        $configs['shipping_amount'] = $this->getFormattedAmount($order->getShippingAmount());
        $configs['discount_amount'] = $this->getFormattedAmount($order->getDiscountAmount());

        $configs['CustomerFirstName'] = $order->getBillingAddress()->getFirstname();
        $configs['CustomerLastName'] = $order->getBillingAddress()->getLastname();
        $configs['CustomerEmail'] = $order->getBillingAddress()->getEmail();
        $configs['CustomerPhone'] = $order->getBillingAddress()->getTelephone();
        $configs['CustomerCity'] = $order->getBillingAddress()->getCity();
        $configs['CustomerRegion'] = $order->getBillingAddress()->getRegion();
        $configs['CustomerZIP'] = $order->getBillingAddress()->getPostcode();
        $configs['CustomerCountry'] = $order->getBillingAddress()->getCountryId();
        $configs['CustomerAddress'] = $address;

        $address2 = implode (",", $order->getShippingAddress()->getStreet());
        $configs['ShipCustomerFirstName'] = $order->getShippingAddress()->getFirstname();
        $configs['ShipCustomerLastName'] = $order->getShippingAddress()->getLastname();
        $configs['ShipCustomerCity'] = $order->getShippingAddress()->getCity();
        $configs['ShipCustomerRegion'] = $order->getShippingAddress()->getRegion();
        $configs['ShipCustomerZIP'] = $order->getShippingAddress()->getPostcode();
        $configs['ShipCustomerCountry'] = $order->getShippingAddress()->getCountryId();
        $configs['ShipCustomerAddress'] = $address2;
        
        $selected_country = $model->getConfigValue('new_payment_country');
        if ($selected_country == "SG") {
            $configs['OCTIFI_SCRIPT_SRC'] = $_OCTIFI_ENV['OCTIFI_SCRIPT_SRC_SG'];
        }
        elseif ($selected_country == "MY") {
            $configs['OCTIFI_SCRIPT_SRC'] = $_OCTIFI_ENV['OCTIFI_SCRIPT_SRC_MY'];
        }
	else{
            $configs['OCTIFI_SCRIPT_SRC'] = $_OCTIFI_ENV['OCTIFI_SCRIPT_SRC'];
        }
	    
        return $configs;
    }
    
    public function getFormattedAmount($amount) {
        return round($amount, 2);
    }
}
