<?php

namespace Octifi\Octifi\Block;

class Success extends \Magento\Framework\View\Element\Template
{
    protected $helper;
    protected $payment;

    public function __construct(
        \Octifi\Octifi\Helper\Data $helper,
        \Octifi\Octifi\Model\Pay $payment,
        \Magento\Catalog\Block\Product\Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->helper = $helper;
        $this->payment = $payment;
    }
    
    public function getStatusContent()
    {
        $order = $this->payment->getOrder();
        $payment = $order->getPayment();
        $method = $payment->getMethodInstance();
        if ($method && $payment->getMethod() == 'octifi') {
            $status_content = '';

            if ($order->getState() == \Magento\Sales\Model\Order::STATE_NEW) {
                $status_content = __('Your payment status is pending, we will update the status as soon as we receive notification from Octifi Payment.');
            } else if ($order->getState() == \Magento\Sales\Model\Order::STATE_PROCESSING) {
                $status_content = __('Your payment is successful with Octifi Payment.');
            } else if ($order->getState() == \Magento\Sales\Model\Order::STATE_CANCELED) {
                $status_content = __('Your payment is failed with Octifi Payment.');
            }

            return $status_content;
        }
    }
}
