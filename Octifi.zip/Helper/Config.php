<?php
namespace Octifi\Octifi\Helper;

class Config extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var array environment values
     */
    public $envConfig = [];

    /**
     * Constructor
     */
    public function __construct()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $dir = $objectManager->get(\Magento\Framework\Module\Dir::class);
        $base = $dir->getDir('Octifi_Octifi');
        $envPath = $base . '/vendor/octifienv/.env';
        $array = \parse_ini_file($envPath, true);

        if ($array === false) {
            throw new \RuntimeException("Failed to parse '{$envPath}' as .env file");
        }

        $this->envConfig = $array;
    }

    /**
     * Gets environment values as array
     *
     * @return array environment config
     */
    public function getEnvConfig()
    {
        return $this->envConfig;
    }
}
