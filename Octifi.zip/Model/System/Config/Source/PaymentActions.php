<?php

namespace Octifi\Octifi\Model\System\Config\Source;

class PaymentActions implements \Magento\Framework\Option\ArrayInterface
{

    /**
     * To option array
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
                ['value' => 'authorise', 'label' => __('Authorization')],
                ['value' => 'capture', 'label' => __('Authorise & Capture')],
        ];
    }
}
