<?php

namespace Octifi\Octifi\Model\System\Config\Source;

class SelectCountry implements \Magento\Framework\Option\ArrayInterface
{

    /**
     * To option array
     *
     * @return array
     */
    public function toOptionArray()
    {
        $objectManager =  \Magento\Framework\App\ObjectManager::getInstance();
        $storeManager =$objectManager->get(\Magento\Store\Model\StoreManagerInterface::class);
        $currency_code = $storeManager->getStore()->getCurrentCurrencyCode();

        return [
                ['value' => '', 'label' => __('Select Country')],
                ['value' => 'SG', 'label' => __('Singapore')],
                ['value' => 'MY', 'label' => __('Malaysia')],
        ];
    }
}
