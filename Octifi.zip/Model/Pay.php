<?php
/**
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Octifi\Octifi\Model;

use Magento\Quote\Api\Data\PaymentInterface;
use Magento\Framework\DataObject;

class Pay extends \Magento\Payment\Model\Method\AbstractMethod
{
    /**
     * Payment method code
     *
     * @var string
     */
    protected $_code = 'octifi';

    /**
     * @var bool
     */
    protected $_isInitializeNeeded = true;
    
    /**
     *
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;

    /**
     *
     * @var \Magento\Sales\Model\OrderFactory
     */
    protected $orderFactory;

    /**
     *
     * @var Magento\Checkout\Model\Session
     */
    protected $orderSession;
    
    /**
     *
     * @var Octifi\Octifi\Helper\Data
     */
    protected $octifiHelper;
    
    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $urlBuilder;
    
    /**
     * @var \Magento\Framework\App\Filesystem\DirectoryList
     */
    protected $directory_list;
    
    /**
     * Constructor
     *
     * @param \Octifi\Octifi\Helper\Data $octifiHelper
     * @param \Magento\Checkout\Model\Session $orderSession
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Framework\UrlInterface $urlBuilder
     * @param \Magento\Framework\App\Filesystem\DirectoryList $directory_list
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory
     * @param \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory
     * @param \Magento\Payment\Helper\Data $paymentData
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Payment\Model\Method\Logger $logger
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb $resourceCollection
     * @param array $data
     * @param \Magento\Directory\Helper\Data $directory
     */
    public function __construct(
        \Octifi\Octifi\Helper\Data $octifiHelper,
        \Magento\Checkout\Model\Session $orderSession,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\UrlInterface $urlBuilder,
        \Magento\Framework\App\Filesystem\DirectoryList $directory_list,
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
        \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
        \Magento\Payment\Helper\Data $paymentData,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Payment\Model\Method\Logger $logger,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = [],
        \Magento\Directory\Helper\Data $directory = null
    ) {
        $this->octifiHelper = $octifiHelper;
        $this->orderSession = $orderSession;
        $this->orderFactory = $orderFactory;
        $this->customerSession = $customerSession;
        $this->urlBuilder = $urlBuilder;
        $this->directory_list = $directory_list;

        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $logger,
            $resource,
            $resourceCollection,
            $data,
            $directory
        );
    }

    /**
     * Get instructions text from config
     *
     * @return string
     */
    public function getInstructions()
    {
        return '';
    }
    
    /**
     * Gets config value
     *
     * @param string $key
     * @return string
     */
    public function getConfigValue($key)
    {
        $pathConfig = 'payment/' . $this->_code . "/" . $key;
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        return $this->_scopeConfig->getValue($pathConfig, $storeScope);
    }
    
    /**
     * Gets checkout
     *
     * @return object
     */
    public function getCheckout()
    {
        return $this->orderSession;
    }
    
    /**
     * Gets quote
     *
     * @return mixed
     */
    public function getQuote()
    {
        return $this->getCheckout()->getQuote();
    }
    
    /**
     * Gets order
     *
     * @return object
     */
    public function getOrder()
    {
        return $this->getCheckout()->getLastRealOrder();
    }

    /**
     * Gets checkout redirect URL
     *
     * @param array $params
     * @return string
     */
    public function getCheckoutRedirectUrl($params = [])
    {
        return $this->urlBuilder->getUrl('octifi/index/pay', $params);
    }

    /**
     * Gets callback URL
     *
     * @param array $params
     * @return string
     */
    public function getCallbackUrl($params = [])
    {
        return $this->urlBuilder->getUrl('octifi/index/callback', $params);
    }
    
    /**
     * Gets cancel URL
     *
     * @param array $params
     * @return string
     */
    public function getCancelUrl($params = [])
    {
        return $this->urlBuilder->getUrl('octifi/index/cancel', $params);
    }
    
    /**
     * Gets checkout success URL
     *
     * @return string
     */
    public function getCheckoutSuccessUrl()
    {
        return $this->urlBuilder->getUrl('checkout/onepage/success');
    }
    
    /**
     * Gets checkout cart URL
     *
     * @return string
     */
    public function getCheckoutCartUrl()
    {
        return $this->urlBuilder->getUrl('checkout/cart');
    }
    
    /**
     * Gets store URL
     *
     * @return string
     */
    public function getStoreUrl()
    {
        return $this->urlBuilder->getUrl();
    }
    
    /**
     * Gets store name
     *
     * @return string
     */
    public function getStoreName()
    {
        $objectManager =  \Magento\Framework\App\ObjectManager::getInstance();
        $storeManager = $objectManager->get(\Magento\Store\Model\StoreManagerInterface::class);
        $storeName = $storeManager->getStore()->getName();
        if (empty($storeName)) {
            $storeName = $storeManager->getStore()->getStoreUrl();
        }
        return $storeName;
    }
    
    /**
     * Log
     *
     * @param string $message
     */
    public function log($message)
    {
        $debug = false;
        if ($debug) {
            $octifiLogFile = $this->directory_list->getPath('log') . '/octifi.log';
            file_put_contents($octifiLogFile, date("Y-m-d H:i:s").": ", FILE_APPEND);
            file_put_contents($octifiLogFile, print_r($message, true), FILE_APPEND);
            file_put_contents($octifiLogFile, "\n", FILE_APPEND);
        }
    }
    
    /**
     * Gets config data
     *
     * @param string $field
     * @param string $storeId
     *
     * @return string
     */
    public function getConfigData($field, $storeId = null)
    {
        if ('order_status' === $field) {
            return 'pending';
        } else {
            return parent::getConfigData($field, $storeId);
        }
    }
    
    /**
     * Is initialize needed?
     *
     * @return bool
     */
    public function isInitializeNeeded()
    {
        return $this->_isInitializeNeeded;
    }
}
