<?php

namespace Octifi\Octifi\Model\System\Config\Source;

class PaymentTypes implements \Magento\Framework\Option\ArrayInterface {

    public function toOptionArray() {
        return [
                ['value' => 'redirect', 'label' => __('Redirect to Gateway')],
                ['value' => 'hosted', 'label' => __('Hosted Modal Popup')],
        ];
    }
}
